  <div class="copyright">
    <p>
      Сделалa Linata, на интенсиве от
      <a href="http://webcademy.ru" target="_blank">WebCademy.ru</a>
    </p>
  </div>

  <script src="js/main.js"></script>
</body>

</html>