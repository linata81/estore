<div class="header">
  <div class="row">
    <div class="col-sm-6">
      <a href="index.php" class="site-logo">
        <span>техно</span>Store
      </a>
    </div>
    <div class="col-sm-6">
      <div class="admin-link">
        <!-- <i class="fas fa-unlock-alt"></i> -->
        <a href="./login.php">
          <img width="38" src="img/icons/padlock.svg" alt="">
        </a>
      </div>
    </div>
  </div>
</div>
