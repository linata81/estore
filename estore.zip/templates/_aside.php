<div class="col-md-3 col-lg-2"> 
  <ul class="nav">
    <li class="nav__element"><a href="index.php" class="nav__link">Все товары</a></li>
    <li class="nav__element"><a href="index.php?productCategory=Телефоны" class="nav__link">Телефоны</a></li>
    <li class="nav__element"><a href="index.php?productCategory=Планшеты" class="nav__link">Планшеты</a></li>
    <li class="nav__element"><a href="index.php?productCategory=Ноутбуки" class="nav__link nav__link--active">Ноутбуки</a></li>
    <li class="nav__element"><a href="index.php?productCategory=Компьютеры" class="nav__link">Компьютеры</a></li>
  </ul>
</div>
