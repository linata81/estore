<?php 

// 1.Создаем подключение и записываем его в переменную dataBase
$db = new PDO('mysql:host=localhost;dbname=esore;charset=utf8', 'mysql', 'mysql');

?>